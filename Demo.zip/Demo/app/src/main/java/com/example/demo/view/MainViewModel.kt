package com.example.demo.view

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.demo.data.remote.model.DogResponse
import com.example.demo.data.repo.DogRepository
import com.example.demo.data.utils.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val dogRepository: DogRepository
) : ViewModel() {

    private val _dogResponse: MutableLiveData<NetworkResult<DogResponse>> = MutableLiveData()
    val dogResponse: LiveData<NetworkResult<DogResponse>> = _dogResponse

    fun getDogResponse() {
        viewModelScope.launch {
            dogRepository.getDogResponse().collect {
                _dogResponse.value = it
            }
        }
    }

}