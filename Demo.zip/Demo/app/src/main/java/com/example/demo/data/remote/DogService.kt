package com.example.demo.data.remote

import com.example.demo.data.remote.model.DogResponse
import com.example.demo.utils.Constants
import retrofit2.Response
import retrofit2.http.GET

interface DogService {

    @GET(Constants.RANDOM_URL)
    suspend fun getDog(): Response<DogResponse>

}