package com.example.demo.view

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.demo.data.utils.NetworkResult
import com.example.demo.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel by viewModels<MainViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.txtHello.text = "Deepak"

        viewModel.getDogResponse()
        viewModel.dogResponse.observe(this) {
            when (it) {
                is NetworkResult.Success -> {
                    Log.d("Main", ">>>> Success: ${it.data}")
                }
                is NetworkResult.Error -> {
                    Log.d("Main", ">>>> Error: ${it.message}")
                }
                is NetworkResult.Loading -> {
                    Log.d("Main", ">>>> Loading: ${it.message}")
                }
            }
        }

    }
}