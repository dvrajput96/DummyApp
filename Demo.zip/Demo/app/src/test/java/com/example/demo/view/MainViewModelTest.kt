package com.example.demo.view

import com.example.demo.data.remote.model.DogResponse
import com.example.demo.data.repo.DogRepository
import com.example.demo.data.utils.NetworkResult
import com.example.demo.getOrAwaitValueTest
import com.google.common.truth.Truth.assertThat
import io.mockk.MockKAnnotations
import io.mockk.mockk
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Before
import org.junit.Test


class MainViewModelTest {

    private val dogRepository: DogRepository = mockk()
    private val viewModel: MainViewModel = MainViewModel(dogRepository)

    @Before
    fun setup() {
        MockKAnnotations.init(this)
    }

    @After
    fun clear() {

    }

    @Test
    fun `Test viewmodel dog call method`() = runBlocking {

        val dogResponse: DogResponse = mockk()

        viewModel.getDogResponse()
        val result = viewModel.dogResponse.getOrAwaitValueTest()

        assertThat(result.data?.status).isEqualTo(NetworkResult.Success(dogResponse))
    }

}