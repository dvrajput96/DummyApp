package com.example.demo.data.repo

import com.example.demo.data.remote.RemoteDataSource
import com.example.demo.data.remote.model.DogResponse
import com.example.demo.data.utils.NetworkResult
import com.example.demo.data.utils.safeApiCall
import dagger.hilt.android.scopes.ActivityRetainedScoped
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

@ActivityRetainedScoped
class DogRepository @Inject constructor(
    private val remoteDataSource: RemoteDataSource
) {

    suspend fun getDogResponse(): Flow<NetworkResult<DogResponse>> {
        return safeApiCall { remoteDataSource.getDog() }
    }
}